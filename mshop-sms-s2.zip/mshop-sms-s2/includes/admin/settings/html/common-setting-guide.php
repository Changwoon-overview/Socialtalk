<style>
    div.alimtalk-desc {
        padding: 5px 0
    }

    div.alimtalk-desc p {
        font-size: 11px;
        margin: 0;
    }
</style>
<div class="alimtalk-desc desc2">
    <p class="alimtalk-desc-title">공통 설정은 문자, 알림톡 공통으로 적용되는 설정으로, 개별 설정이 되지 않습니다.</p>
</div>
