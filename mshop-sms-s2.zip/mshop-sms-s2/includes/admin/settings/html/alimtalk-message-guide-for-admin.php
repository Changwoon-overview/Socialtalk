<style>
    div.alimtalk-desc {
        padding: 5px;
    }

    div.alimtalk-desc p {
        font-size: 11px;
        margin: 0;
    }

    div.alimtalk-desc p.alimtalk-desc-title {
        font-weight: bold;
    }

    div.alimtalk-desc p.alimtalk-desc-content {
        padding-left: 10px;
    }

</style>
<div class="alimtalk-desc">
    <p class="alimtalk-desc-title">[1] 대체 발송이란?</p>
    <p class="alimtalk-desc-content">- 카카오 알림톡 전송 실패 (카카오톡을 사용하지 않는 고객, 알림톡 차단을 선택한 고객) 시, 일반 문자로 대체 발송하는 기능입니다.</p>
    <p class="alimtalk-desc-content">- 대체 발송은 문자 서비스 신청이 되어 있어야 하며, 문자 길이에 따라 단문 및 장문으로 발송 됩니다. 문자 발송의 경우 별도의 이용료가 부과 됩니다.</p>
</div>
